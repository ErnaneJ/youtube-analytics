pip install tkinter
pip install numpy as np
pip install matplotlib
pip install seaborn
pip install pandas